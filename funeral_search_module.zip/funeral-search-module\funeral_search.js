const funeralSearchInput = document.getElementById('funeralSearch');
const funeralSearchIcon = document.getElementById('funeralSearchIcon');
const autocompleteWrapper = document.getElementById('autocompleteWrapper');
const autocompleteList = document.getElementById('autocompleteList');

let searchTimeout = null;

document.addEventListener('click', (e) => {
    if (!funeralSearchInput.contains(e.target) && !autocompleteWrapper.contains(e.target)) {
        autocompleteWrapper.classList.add('hidden');
    }
});

funeralSearchInput.addEventListener('focus', () => {
    if (funeralSearchInput.value.trim() && autocompleteList.innerHTML !== '') {
        autocompleteWrapper.classList.remove('hidden');
    }
});

funeralSearchInput.addEventListener('input', (e) => {
    const keyword = e.target.value.trim();
    
    if(keyword) {
        funeralSearchIcon.className = 'fa-solid fa-circle-notch fa-spin text-teal-mint text-sm transition';
    } else {
        funeralSearchIcon.className = 'fa-solid fa-magnifying-glass text-slate-400 text-sm transition';
        autocompleteWrapper.classList.add('hidden');
        autocompleteList.innerHTML = '';
    }

    clearTimeout(searchTimeout);
    if (!keyword) return;

    searchTimeout = setTimeout(async () => {
        try {
            // 본인의 백엔드 라우터 경로에 맞게 수정
            const response = await fetch(`/api/funeralHalls?searchQuery=${encodeURIComponent(keyword)}`);
            const data = await response.json();
            const results = data.data || [];
            
            funeralSearchIcon.className = 'fa-solid fa-magnifying-glass text-slate-400 text-sm transition';
            autocompleteList.innerHTML = '';
            
            if (results.length === 0) {
                autocompleteList.innerHTML = `
                    <li class="p-4 text-center text-slate-400 text-[0.8rem]">
                        '${keyword}' 검색 결과가 없습니다.
                    </li>
                `;
            } else {
                results.forEach(hospital => {
                    const li = document.createElement('li');
                    li.className = "p-3 bg-white rounded-xl cursor-pointer hover:bg-teal-50 border border-transparent hover:border-teal-100 mb-1 last:mb-0 transition group";
                    li.innerHTML = `
                        <div class="flex items-start gap-3">
                            <div class="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-400 group-hover:bg-teal-mint group-hover:text-white transition shadow-sm shrink-0">
                                <i class="fa-solid fa-building-circle-check text-[0.7rem]"></i>
                            </div>
                            <div class="flex-1 overflow-hidden">
                                <h4 class="font-bold text-slate-800 text-[0.9rem] mb-0.5 group-hover:text-teal-700 truncate transition">${hospital.name}</h4>
                                <p class="text-[0.65rem] text-slate-500 truncate"><i class="fa-solid fa-map-location-dot mr-1 text-slate-400"></i>${hospital.address}</p>
                            </div>
                        </div>
                    `;
                    li.addEventListener('click', () => {
                        funeralSearchInput.value = hospital.name;
                        autocompleteWrapper.classList.add('hidden');
                    });
                    autocompleteList.appendChild(li);
                });
            }
            autocompleteWrapper.classList.remove('hidden');
        } catch (error) {
            console.error("검색 오류", error);
            funeralSearchIcon.className = 'fa-solid fa-magnifying-glass text-slate-400 text-sm transition';
        }
    }, 500);
});
