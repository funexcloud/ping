const axios = require('axios');

// [중요 설정 값] 본인의 공공데이터 일반인증키로 교체
const FUNERAL_API_KEY = 'YOUR_API_KEY_HERE';
const FUNERAL_API_ENDPOINT = 'https://apis.data.go.kr/1352000/ODMS_DATA_04_1/callData04_1Api';

let globalFuneralHallsCache = null;

async function fetchAllFuneralHallsFromAPI() {
    console.log('Fetching ALL funeral halls from public API into memory cache...');
    const allHalls = [];
    const maxPages = 4;
    const numOfRows = 500; // 공공데이터 강제 한도

    for(let pageNo = 1; pageNo <= maxPages; pageNo++) {
        // [중요 버그 픽스] 공공데이터 포털의 XML 2페이지 호출 404 버그를 피하기 위해 무조건 apiType=JSON 사용
        const apiUrl = `${FUNERAL_API_ENDPOINT}?serviceKey=${encodeURIComponent(FUNERAL_API_KEY)}&pageNo=${pageNo}&numOfRows=${numOfRows}&apiType=JSON`;
        try {
            const response = await axios.get(apiUrl, { headers: { Accept: 'application/json' }, timeout: 10000 });
            const itemsData = response.data?.items;
            
            if (!itemsData || itemsData.length === 0) break; // 마지막 페이지 도달
            
            const items = Array.isArray(itemsData) ? itemsData : [itemsData];
            const parsedItems = items.filter(Boolean).map(item => ({
                name: item?.fcltNm || item?.facltNm || item?.facilityName || item?.funeralHallName || item?.funeralHallNm || item?.name || '',
                address: item?.rdnmadr || item?.lnmadr || item?.address || item?.addr || '',
                phone: item?.telno || item?.phone || item?.tel || ''
            })).map(item => ({
                name: String(item.name).trim(),
                address: String(item.address).trim(),
                phone: String(item.phone).trim()
            })).filter(item => item.name);

            allHalls.push(...parsedItems);
        } catch (error) {
            console.error(`Error fetching page ${pageNo}:`, error.message);
            break;
        }
    }
    
    const uniqueHalls = Array.from(new Map(allHalls.map(item => [item.name + item.address, item])).values());
    console.log(`Cache populated strictly with ${uniqueHalls.length} funeral halls.`);
    return uniqueHalls;
}

// 서버 시작 시 예약 로드 (선택 사항)
fetchAllFuneralHallsFromAPI().then(halls => {
    globalFuneralHallsCache = halls;
}).catch(console.error);

async function getFuneralHalls(searchQuery = '') {
    if (!globalFuneralHallsCache || globalFuneralHallsCache.length === 0) {
        globalFuneralHallsCache = await fetchAllFuneralHallsFromAPI();
    }
    
    if (!searchQuery || searchQuery.length < 2) return globalFuneralHallsCache.slice(0, 50);

    const lowered = searchQuery.toLowerCase();
    const results = globalFuneralHallsCache.filter(item =>
        item.name.toLowerCase().includes(lowered) ||
        item.address.toLowerCase().includes(lowered)
    );
    
    return results.slice(0, 100);
}

// Express 등 프레임워크 라우터 내보내기용 예제
module.exports = {
    getFuneralHalls,
    handleRequest: async (req, res) => {
        try {
            const searchQuery = String(req.query.searchQuery || '').trim();
            const funeralHalls = await getFuneralHalls(searchQuery);
            res.status(200).json({ success: true, data: funeralHalls, totalCount: funeralHalls.length });
        } catch (error) {
            res.status(500).json({ error: '목록 호출 실패' });
        }
    }
};
